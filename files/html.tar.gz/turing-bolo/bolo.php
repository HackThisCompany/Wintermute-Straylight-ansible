<html>
<style>
.row {
  display: flex;
}

.column {
  flex: 33.33%;
  padding: 5px;
}

body {
    color: #ff7614;
}
</style>


<body style="background-color:#3d3d3d;">
<i>Sponsored by:</i> <b style="color:cyan;">Hosaka - <i>"Break the ICE" </i></b><br/>
<img src="c7.png"> <br/><br/>
*********************************************************************
*********************************************************************
<br/>
<?php
   if ( isset( $_GET['bolo'] ) ) {
      include( $_GET['bolo'] . '.log' );
   }
?>


</body>
</html>
