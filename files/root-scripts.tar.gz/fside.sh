#!/bin/bash
sh /root/scripts/frun.sh
