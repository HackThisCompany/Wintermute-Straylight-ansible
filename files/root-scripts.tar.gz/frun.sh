#!/bin/bash
/bin/screen -S free -d -m sh /root/scripts/freeside.sh
