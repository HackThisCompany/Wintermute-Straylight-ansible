#!/bin/bash
sh /root/scripts/loop.sh
