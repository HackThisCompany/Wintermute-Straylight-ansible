#!/bin/bash
while true 
do curl http://127.0.0.1/freeside/ & sleep 10
done
