#!/bin/bash
while true 
do curl http://127.0.0.1/turing-bolo/ & sleep 3
done
